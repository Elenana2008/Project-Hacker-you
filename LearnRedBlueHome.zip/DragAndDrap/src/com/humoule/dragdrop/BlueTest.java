package com.humoule.dragdrop;

import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.Toast;

public class BlueTest extends Activity implements OnLoadCompleteListener {
	final String LOG_TAG = "myLogs";
	final int MAX_STREAMS = 5;
	SoundPool sp, sp1;
	int soundWrong;
	int soundRight;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.blue);
		ImageButton imageButton1 = (ImageButton) findViewById(R.id.imageButton1);
		ImageButton imageButton2 = (ImageButton) findViewById(R.id.imageButton2);
		ImageButton imageButton3 = (ImageButton) findViewById(R.id.imageButton3);
		ImageButton imageButton4 = (ImageButton) findViewById(R.id.imageButton4);
		imageButton1.setOnClickListener(imageListener);
		imageButton2.setOnClickListener(imageListener);
		imageButton3.setOnClickListener(imageListener);
		imageButton4.setOnClickListener(imageListener);

		sp = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp.setOnLoadCompleteListener(this);
		sp1 = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp1.setOnLoadCompleteListener(this);
		try {
			soundWrong = sp.load(getAssets().openFd("ploho.wav"), 1);
			soundRight = sp1.load(getAssets().openFd("Molodez.wav"), 1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.d(LOG_TAG, "soundIdExplosion = " + soundWrong);

	}

	private OnClickListener imageListener = new OnClickListener() {

		@Override
		public void onClick(View view) {

			
			switch (view.getId()) {
			case R.id.imageButton1:
				Toast.makeText(getBaseContext(), "Cucumber is NOT blue! ",
						Toast.LENGTH_SHORT).show();
				ImageButton wrong = (ImageButton) findViewById(R.id.imageButton1);
				wrong.setImageResource(R.drawable.wrong3);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton2:
				Toast.makeText(getBaseContext(), "Tractor is NOT blue!",
						Toast.LENGTH_SHORT).show();
				ImageButton wrong1 = (ImageButton) findViewById(R.id.imageButton2);
				wrong1.setImageResource(R.drawable.wrong3);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton3:
				Toast.makeText(getBaseContext(), "Watermelon is NOT blue!",
						Toast.LENGTH_SHORT).show();
				ImageButton wrong3 = (ImageButton) findViewById(R.id.imageButton3);
				wrong3.setImageResource(R.drawable.wrong3);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton4:
				Toast.makeText(getBaseContext(), "Good!",
						Toast.LENGTH_SHORT).show();
				ImageButton right1 = (ImageButton) findViewById(R.id.imageButton4);
				right1.setImageResource(R.drawable.right1);
				sp1.play(soundRight, 1, 1, 0, 1, 1);
				Intent intent = new Intent(getBaseContext(), GreenTest.class);
			startActivity(intent);
				break;
			}

		}
	};

	//@Override
	//public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
	//	getMenuInflater().inflate(R..main, menu);
	//	return true;
//	}

	//@Override
	//public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
	//	int id = item.getItemId();
	//	if (id == R.id.action_settings) {
	//		return true;
	//	}
	//	return super.onOptionsItemSelected(item);
	//}

	@Override
	public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
		Log.d(LOG_TAG, "onLoadComplete, sampleId = " + sampleId + ", status = "
				+ status);

	}


}




/*

package com.example.colorsgame;

import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends Activity implements OnLoadCompleteListener {
	final String LOG_TAG = "myLogs";
	final int MAX_STREAMS = 5;
	SoundPool sp, sp1;
	int soundWrong;
	int soundRight;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.red);
		ImageButton imageButton1 = (ImageButton) findViewById(R.id.imageButton1);
		ImageButton imageButton2 = (ImageButton) findViewById(R.id.imageButton2);
		ImageButton imageButton3 = (ImageButton) findViewById(R.id.imageButton3);
		ImageButton imageButton4 = (ImageButton) findViewById(R.id.imageButton4);
		imageButton1.setOnClickListener(imageListener);
		imageButton2.setOnClickListener(imageListener);
		imageButton3.setOnClickListener(imageListener);
		imageButton4.setOnClickListener(imageListener);

		sp = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp.setOnLoadCompleteListener(this);
		sp1 = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp1.setOnLoadCompleteListener(this);
		try {
			soundWrong = sp.load(getAssets().openFd("explosion.ogg"), 1);
			soundRight = sp1.load(getAssets().openFd("Mistake.wav"), 1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.d(LOG_TAG, "soundIdExplosion = " + soundWrong);

	}

	private OnClickListener imageListener = new OnClickListener() {

		@Override
		public void onClick(View view) {

			
			switch (view.getId()) {
			case R.id.imageButton1:
				Toast.makeText(getBaseContext(), "1 is clicked!",
						Toast.LENGTH_SHORT).show();
				ImageButton wrong = (ImageButton) findViewById(R.id.imageButton1);
				wrong.setImageResource(R.drawable.wrong3);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton2:
				Toast.makeText(getBaseContext(), "2 is clicked!",
						Toast.LENGTH_SHORT).show();
				ImageButton wrong1 = (ImageButton) findViewById(R.id.imageButton2);
				wrong1.setImageResource(R.drawable.wrong3);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton3:
				Toast.makeText(getBaseContext(), "3 is clicked!",
						Toast.LENGTH_SHORT).show();
				ImageButton wrong3 = (ImageButton) findViewById(R.id.imageButton3);
				wrong3.setImageResource(R.drawable.wrong3);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton4:
				Toast.makeText(getBaseContext(), "4 is clicked!",
						Toast.LENGTH_SHORT).show();
				ImageButton right1 = (ImageButton) findViewById(R.id.imageButton4);
				right1.setImageResource(R.drawable.right1);
				sp1.play(soundRight, 1, 1, 0, 1, 1);
				Intent intent = new Intent(getBaseContext(), BlueTest.class);
				startActivity(intent);
				break;
			}

		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
		Log.d(LOG_TAG, "onLoadComplete, sampleId = " + sampleId + ", status = "
				+ status);

	}
}







*/