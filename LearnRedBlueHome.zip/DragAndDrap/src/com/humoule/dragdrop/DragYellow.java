package com.humoule.dragdrop;

import java.io.IOException;

import com.humoule.dragdrop.R;

import android.app.Activity;
import android.content.ClipData;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class DragYellow extends Activity implements View.OnDragListener,
OnTouchListener,OnLoadCompleteListener {

	private static String TAG; // = MainActivity.class.getSimpleName();

	private final String IMAGE_RED_CIRCLE = "RedCircle";
	private final String IMAGE_GREEN_CIRCLE = "GreenC";
	private final String IMAGE_YELLOW_CIRCLE = "YellowCircle";
	private final String IMAGE_WRONG = "Wrong";

	private ImageView dragViewRedCircle;
	private ImageView dragViewGreenCircle;
	private ImageView dragViewYellowCircle;
	private ImageView wrong;
	private ImageView dropView;
	View.DragShadowBuilder mShadow;

	String selectedTag;
	final String LOG_TAG = "myLogs";
	final int MAX_STREAMS = 5;
	SoundPool sp, sp1,sp2;
	int soundWrong;
	int soundRight;
	int soundNotRed;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_drag1);

		TAG = DragYellow.class.getSimpleName();

		dragViewGreenCircle = (ImageView) findViewById(R.id.GreenCircle);
		dragViewRedCircle = (ImageView) findViewById(R.id.RedCircle);
		dragViewYellowCircle = (ImageView) findViewById(R.id.YellowCircle);
		dropView = (ImageView) findViewById(R.id.dropImage);

		// settings tags to all images

		dragViewGreenCircle.setTag(IMAGE_GREEN_CIRCLE);
		dragViewRedCircle.setTag(IMAGE_RED_CIRCLE);
		dragViewYellowCircle.setTag(IMAGE_YELLOW_CIRCLE);

		dropView.setTag(IMAGE_YELLOW_CIRCLE);

		dragViewGreenCircle.setOnTouchListener(this);
		dragViewRedCircle.setOnTouchListener(this);
		dragViewYellowCircle.setOnTouchListener(this);
		dropView.setOnDragListener(this);
		sp = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp.setOnLoadCompleteListener((OnLoadCompleteListener) this);
		sp1 = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp1.setOnLoadCompleteListener((OnLoadCompleteListener) this);
		sp2 = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp2.setOnLoadCompleteListener((OnLoadCompleteListener) this);
		try {
			soundWrong = sp.load(getAssets().openFd("banana its not green.wav"), 1);
			soundRight = sp1.load(getAssets().openFd("Molodez.wav"), 1);
			soundNotRed=sp2.load(getAssets().openFd("banana its not red.wav"), 1);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.d(LOG_TAG, "soundIdExplosion = " + soundWrong);

	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		String tag = v.getTag().toString();

		switch (event.getAction()) {// 1
		case MotionEvent.ACTION_DOWN:
			ClipData data = ClipData.newPlainText("some label", tag);

			selectedTag = tag;
			if (tag.equals(IMAGE_GREEN_CIRCLE)) {
				dropView.setImageResource(R.drawable.circle_green);
				mShadow = new View.DragShadowBuilder(dragViewGreenCircle);
			} else if (tag.equals(IMAGE_RED_CIRCLE)) {
				dropView.setImageResource(R.drawable.circle_red);
				mShadow = new View.DragShadowBuilder(dragViewRedCircle);
			} else if (tag.equals(IMAGE_YELLOW_CIRCLE)) {
				dropView.setImageResource(R.drawable.circle_yellow);
				mShadow = new View.DragShadowBuilder(dragViewYellowCircle);
			}

			v.startDrag(data, mShadow, null, 0);
			break;

		case MotionEvent.ACTION_UP:
			v.performClick();

			break;

		default:
			break;
		}
		return false;
	}

	@Override
	public boolean onDrag(View v, DragEvent event) {
		Log.d(TAG, "onDrag");// log cat only :(((

		// Gets the text data from the item.

		// Store the action type for the incoming event
		final int action = event.getAction();

		// Handles each of the expected events
		switch (action) {
		case DragEvent.ACTION_DRAG_STARTED:

			// In order to inform user that drag has started, we apply yellow
			// tint to view

			// kan mahlitim al zeva shel zel

			((ImageView) v).setColorFilter(Color.YELLOW);

			// Invalidate the view to force a redraw in the new tint
			v.invalidate();

			// Returns true to indicate that the View can accept the
			// dragged data.
			return true;

		case DragEvent.ACTION_DRAG_ENTERED:

			// Apply a gray tint to the View
			((ImageView) v).setColorFilter(Color.LTGRAY);

			// Invalidate the view to force a redraw in the new tint
			v.invalidate();

			return true;

		case DragEvent.ACTION_DRAG_LOCATION:

			// Ignore the event
			return true;

		case DragEvent.ACTION_DRAG_EXITED:

			// Re-sets the color tint to yellow
			((ImageView) v).setColorFilter(Color.YELLOW);

			// Invalidate the view to force a redraw in the new tint
			v.invalidate();

			return true;

		case DragEvent.ACTION_DROP:

			// Gets the item containing the dragged data

			ClipData dragData = event.getClipData();

			final String tag = dragData.getItemAt(0).getText().toString();

			if (tag.equals(IMAGE_GREEN_CIRCLE)) {
				Toast.makeText(DragYellow.this, "Banana is not green !!!",
						Toast.LENGTH_SHORT).show();
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				// dragViewGreenCircle.setBackground(background);
				// ImageButton wrong = (ImageButton)
				// findViewById(R.id.GreenCircle);
				// wrong.setImageResource(R.drawable.banana);
				
				//lama lo oved?
				dropView.setImageResource(R.id.dropImage);

				return false;

			} else if (tag.equals(IMAGE_YELLOW_CIRCLE)) {
				sp1.play(soundRight, 1, 1, 0, 1, 1);
				
			} else if (tag.equals(IMAGE_RED_CIRCLE)) {

				Toast.makeText(DragYellow.this, "Banana is not red !!!",
						Toast.LENGTH_SHORT).show();
				sp2.play(soundNotRed, 1, 1, 0, 1, 1);
				//lama lo oved?
				dropView.setImageResource(R.id.dropImage);
				return false;
			}//
				// Displays a message containing the dragged data.

			// Turns off any color tints
			((ImageView) v).clearColorFilter();

			// Invalidates the view to force a redraw
			v.invalidate();

			return true;

		case DragEvent.ACTION_DRAG_ENDED:

			// Turns off any color tinting
			((ImageView) v).clearColorFilter();

			// Invalidates the view to force a redraw
			v.invalidate();

			// Check for result
			if (event.getResult()) {
				if (v.getTag().equals(selectedTag)) {

					Toast.makeText(DragYellow.this, "Bingo !",
							Toast.LENGTH_SHORT).show();
				}

			} else {
				Toast.makeText(DragYellow.this, "Oups, try again !",
						Toast.LENGTH_SHORT).show();
				dropView.setImageBitmap(null);
			}

			return true;

		default:
			break;
		}

		return false;
	}

	@Override
	public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
		Log.d(LOG_TAG, "onLoadComplete, sampleId = " + sampleId + ", status = "
				+ status);
		
	}

}
