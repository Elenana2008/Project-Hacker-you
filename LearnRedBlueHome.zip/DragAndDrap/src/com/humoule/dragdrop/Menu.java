/*
 * To fix the names of sounds
 */
package com.humoule.dragdrop;

import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.Toast;

public class Menu extends Activity implements OnLoadCompleteListener {
	final String LOG_TAG = "myLogs";
	final int MAX_STREAMS = 5;
	
	SoundPool sp, sp1, sp2;// , sp3, sp4;
	int soundWrong;
	int soundRight;
	// int soundPlay;
	// int soundTest;
	int soundLearn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
		ImageButton imageButton1 = (ImageButton) findViewById(R.id.imageButton1);
		ImageButton imageButton2 = (ImageButton) findViewById(R.id.imageButton2);
		ImageButton imageButton3 = (ImageButton) findViewById(R.id.imageButton3);
		imageButton1.setOnClickListener(imageListener);
		imageButton2.setOnClickListener(imageListener);
		imageButton3.setOnClickListener(imageListener);

		sp = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp.setOnLoadCompleteListener(this);
		sp1 = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp1.setOnLoadCompleteListener(this);
		sp2 = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
		sp2.setOnLoadCompleteListener(this);
		

		try {
			soundWrong = sp.load(getAssets().openFd("test.wav"), 1);
			soundRight = sp1.load(getAssets().openFd("play.wav"), 1);
			soundLearn=sp2.load(getAssets().openFd("learn.wav"), 1);
			// soundWrong = sp2.load(getAssets().openFd("learn.wav"), 1);

		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.d(LOG_TAG, "soundIdExplosion = " + soundWrong);

	}

	private OnClickListener imageListener = new OnClickListener() {

		@Override
		public void onClick(View view) {

			switch (view.getId()) {
			case R.id.imageButton1:
				Toast.makeText(getBaseContext(), "Learn!", Toast.LENGTH_SHORT)
						.show();
				
				Intent intent0 = new Intent(getBaseContext(), LearnRed.class);
				startActivity(intent0);
				sp2.play(soundLearn, 1, 1, 0, 1, 1);

				break;
			case R.id.imageButton2:
				Toast.makeText(getBaseContext(), "Play", Toast.LENGTH_SHORT)
						.show();

				Intent intent1 = new Intent(getBaseContext(), DragYellow.class);
				startActivity(intent1);
				sp1.play(soundRight, 1, 1, 0, 1, 1);
				break;
			case R.id.imageButton3:
				Toast.makeText(getBaseContext(), "TEST", Toast.LENGTH_SHORT)
						.show();

				Intent intent2 = new Intent(getBaseContext(),
						MainActivity.class);
				startActivity(intent2);
				sp.play(soundWrong, 1, 1, 0, 1, 1);
				break;

			}

		}
	};

	@Override
	public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
		Log.d(LOG_TAG, "onLoadComplete, sampleId = " + sampleId + ", status = "
				+ status);

	}
}
